import type { FC } from 'react';
import React from 'react';
import clsx from 'clsx';
import { useTranslation } from 'react-i18next';
import { Menu, MenuButton, MenuItem, MenuItems } from '@ecainternational/eca-components';
import { ACTIONS } from '~/components/query-builder/config.ts';

interface ActionSelectorProps {
  onAdd: (type: string, config: unknown) => void;
}
const ActionSelector: FC<ActionSelectorProps> = ({ onAdd }) => {
  const { t } = useTranslation();
  return (
    <Menu className="flex justify-center">
      <MenuButton
        as="button"
        className={clsx(
          'bg-neutral-layer-2 label-sm-mid mx-auto flex w-full max-w-96 items-center justify-center gap-3 rounded-lg px-2 py-3',
          'hover:bg-neutral-layer-3',
        )}
        aria-label={t('globalVariables.rule.addAction')}
      >
        <i className="file: fi-rr-plus flex" aria-hidden />
        <span>{t('globalVariables.rule.addAction')}</span>
      </MenuButton>
      <MenuItems>
        <div className="label-md-heavier p-3">{t('globalVariables.rule.selectActionType')}</div>
        {Object.keys(ACTIONS).map((key: string) => {
          const action = ACTIONS[key];
          return (
            action && (
              <MenuItem key={key}>
                <button className="flex w-full items-center gap-2" onClick={() => onAdd(key, action.defaultConfig)}>
                  <i className={clsx('fi flex', action.icon)} />
                  <span>{t(action.label)}</span>
                </button>
              </MenuItem>
            )
          );
        })}
      </MenuItems>
    </Menu>
  );
};

export default ActionSelector;
