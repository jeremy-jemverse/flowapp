import type { FC } from 'react';
import type { ZodType } from 'zod';
import { z } from 'zod';

export const Combinator = z.enum(['and', 'or']);
export type Combinator = z.infer<typeof Combinator>;

export const FieldType = z.enum(['text', 'number', 'date', 'time', 'boolean', 'select', 'multiselect', 'percentage']);
export type FieldType = z.infer<typeof FieldType>;

export const Operator = z.enum([
  '==',
  '!=',
  '>',
  '<',
  '>=',
  '<=',
  'between',
  'not_between',
  'in',
  'not_in',
  'contains',
  'not_contains',
  'starts_with',
  'ends_with',
  'is_empty',
  'is_not_empty',
]);
export type Operator = z.infer<typeof Operator>;

export const QueryMode = z.enum(['group', 'switch_group']);
export type QueryMode = z.infer<typeof QueryMode>;

export const ValueFieldSource = z.enum(['value', 'field', 'func']);
export type ValueFieldSource = z.infer<typeof ValueFieldSource>;

export interface ActionWidgetProps {
  action: Action;
  onChange(value: any): void;
}

export interface ActionConfig {
  label: string;
  icon: string;
  widget: FC<ActionWidgetProps>;
  defaultConfig: unknown;
}

export interface FuncWidgetProps {
  id: string;
  args: unknown;
  onChange(func: Func): void;
}

export interface FuncArg {
  name: string;
  type: FieldType;
  description: string;
}

export interface FuncConfig {
  name: string;
  description: string;
  arguments: FuncArg[];
  widget: FC<FuncWidgetProps> | null;
  schema: ZodType;
  returnType: FieldType;
  defaultArgs: unknown;
}

export interface Field {
  id: string;
  name: string;
  type: FieldType;
  category?: string;
  description?: string;
  options?: { value: string; label: string }[];
  metadata?: {
    variableType?: string;
    resultType?: string;
  };
}

export interface Rule {
  id: string;
  type: 'rule';
  properties: RuleProperties;
}

export interface RuleProperties {
  field: unknown;
  fieldSrc: ValueFieldSource;
  operator: Operator;
  value: any[];
  valueSrc: ValueFieldSource[];
  valueType: (null | FieldType)[];
}

export interface RuleGroup {
  id: string;
  type: 'group';
  children1: (Rule | RuleGroup)[];
  properties: RuleGroupProperties;
}

export type RuleGroupProperties = {
  conjunction: Combinator;
};

export interface Action {
  id: string;
  type: string;
  config: unknown;
}

export interface Func {
  func: string;
  args: unknown;
}

export interface CaseGroup {
  id: string;
  type: 'case_group';
  children1?: (Rule | RuleGroup)[];
  properties: CaseGroupProperties;
}

export type CaseGroupProperties = {
  conjunction: Combinator;
  actions: Action[];
};

export interface SwitchGroup {
  id: string;
  type: 'switch_group';
  children1: CaseGroup[];
  properties: SwitchGroupProperties;
}

export interface SwitchGroupProperties {}

export type Query = RuleGroup | SwitchGroup;
