import type { FC } from 'react';
import type { Func, FuncWidgetProps, ValueFieldSource } from '~/components/query-builder/types.ts';
import ValueField from '~/components/query-builder/ValueField.tsx';

interface PercentageOfArgs {
  percentage: {
    value: unknown;
    valueSrc: ValueFieldSource;
  };
  totalAmount: {
    value: unknown;
    valueSrc: ValueFieldSource;
  };
}
export const PercentageOf: FC<FuncWidgetProps> = ({ id, args, onChange }) => {
  const percentageOfArgs = args as PercentageOfArgs;
  const { percentage, totalAmount } = percentageOfArgs;
  const handleOnChange = (updatedValue: any) => {
    onChange({
      func: 'percentageOf',
      args: {
        ...percentageOfArgs,
        ...updatedValue,
      },
    } as Func);
  };
  return (
    <>
      <ValueField
        enableValueSource
        id={`${id}_percentageOf_arg1`}
        type="percentage"
        source={percentage.valueSrc}
        value={percentage.value}
        onChange={(value, valueSrc, _) => handleOnChange({ percentage: { value, valueSrc } })}
      />
      <span>, </span>
      <ValueField
        enableValueSource
        id={`${id}_percentageOf_arg2`}
        type="number"
        source={totalAmount.valueSrc}
        value={totalAmount.value}
        onChange={(value, valueSrc, _) => handleOnChange({ totalAmount: { value, valueSrc } })}
      />
    </>
  );
};
