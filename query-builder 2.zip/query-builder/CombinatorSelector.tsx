import { SegmentedControl } from '@ecainternational/eca-components';
import type { FC } from 'react';
import type { Combinator } from '~/components/query-builder/types.ts';

interface CombinatorProps {
  id: string;
  combinator: Combinator;
  onChange: (combinator: Combinator) => void;
}
const CombinatorSelector: FC<CombinatorProps> = ({ id, combinator, onChange }) => {
  return (
    <SegmentedControl size="small" name={`${id}_combinator`} className="w-full max-w-40">
      <input
        type="radio"
        aria-label="AND"
        value="and"
        checked={combinator === 'and'}
        onChange={(event) => onChange(event.target.value as Combinator)}
      />
      <input
        type="radio"
        aria-label="OR"
        value="or"
        checked={combinator === 'or'}
        onChange={(event) => onChange(event.target.value as Combinator)}
        data-highlight="vis-5"
      />
    </SegmentedControl>
  );
};

export default CombinatorSelector;
