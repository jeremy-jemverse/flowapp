import * as React from 'react';
import type { Field } from '~/components/query-builder/types.ts';

type QueryBuilderContextProps = {
  fields: Field[];
};

export const QueryBuilderContext = React.createContext<QueryBuilderContextProps | null>(null);

export function useQueryBuilder() {
  const context = React.useContext(QueryBuilderContext);

  if (!context) {
    throw new Error('useQueryBuilder must be used within a <QueryBuilder />');
  }

  return context;
}
