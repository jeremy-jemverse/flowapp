import type { FC } from 'react';
import type { ValueSelectorProps } from '~/components/query-builder/ValueSelectors/types.ts';
import { useTranslation } from 'react-i18next';
import { TextInput } from '@ecainternational/eca-components';
import { useValidation } from '~/components/query-builder/ValueSelectors/use-validation.ts';

export const PercentageField: FC<ValueSelectorProps<number>> = ({ name, title, value, onChange }) => {
  const { t } = useTranslation();
  const { state } = useValidation('percentage', value);

  return (
    <TextInput
      name={name}
      title={title}
      value={value ?? ''}
      suffix="%"
      type="number"
      className={'me-2 !w-32'}
      placeholder={t('globalVariables.rule.percentagePlaceholder')}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      state={state}
    />
  );
};
