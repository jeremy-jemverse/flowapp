import type { FieldType } from '~/components/query-builder/types.ts';
import { valueSchemas } from '~/components/query-builder/schemas.ts';
import { InputState } from '~/components/plan';

export function useValidation(type: FieldType, value: unknown) {
  const schema = valueSchemas[type];
  const result = schema.safeParse(value);
  const state = result.success ? InputState.DEFAULT : InputState.ERROR;
  return { state };
}
