import type { FC } from 'react';
import { Select } from '@ecainternational/eca-components';
import type { ValueSelectorProps } from '~/components/query-builder/ValueSelectors/types.ts';
import { useValidation } from '~/components/query-builder/ValueSelectors/use-validation.ts';

export const MultiSelectField: FC<ValueSelectorProps<string[]>> = ({ options, name, title, value, onChange }) => {
  const { state } = useValidation('multiselect', value);

  const handleMultiChange = (selectedOptions: HTMLCollectionOf<HTMLOptionElement>) => {
    onChange([...selectedOptions].map((option) => option.value));
  };

  return (
    <Select
      multiple={true}
      name={name}
      title={title}
      value={value ?? ''}
      className="rule-builder__multi-select max-h-20 !w-[186px] !pe-0"
      onChange={(event) => handleMultiChange(event.target.selectedOptions)}
      state={state}
    >
      {options?.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </Select>
  );
};
