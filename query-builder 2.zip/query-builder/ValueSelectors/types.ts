export type ValueSelectorProps<V = any> = {
  name: string;
  title: string;
  value: V | null;
  onChange: (value: V | null) => void;
  options?: { label: string; value: string }[];
};
