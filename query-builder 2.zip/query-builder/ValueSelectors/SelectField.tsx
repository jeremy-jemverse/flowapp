import type { FC } from 'react';
import { useTranslation } from 'react-i18next';
import { Select } from '@ecainternational/eca-components';
import type { ValueSelectorProps } from '~/components/query-builder/ValueSelectors/types.ts';
import { useValidation } from '~/components/query-builder/ValueSelectors/use-validation.ts';

export const SelectField: FC<ValueSelectorProps<string>> = ({ options, name, title, value, onChange }) => {
  const { t } = useTranslation();
  const { state } = useValidation('select', value);

  const handleChange = (value: string) => {
    onChange(value === '' ? null : value);
  };

  return (
    <Select
      name={name}
      title={title}
      value={value ?? ''}
      className="!w-[186px]"
      onChange={(event) => handleChange(event.target.value)}
      state={state}
    >
      <option value="">{t('globalVariables.rule.selectPlaceholder')}</option>
      {options?.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </Select>
  );
};
