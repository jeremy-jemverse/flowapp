import type { FC } from 'react';
import type { ValueSelectorProps } from '~/components/query-builder/ValueSelectors/types.ts';
import { TextInput } from '@ecainternational/eca-components';
import { useValidation } from '~/components/query-builder/ValueSelectors/use-validation.ts';

export const TimeField: FC<ValueSelectorProps<string>> = ({ name, title, value, onChange }) => {
  const { state } = useValidation('time', value);
  return (
    <TextInput
      name={name}
      title={title}
      value={value ?? ''}
      type="time"
      step="2"
      className={'!w-40'}
      onChange={(e) => onChange(e.target.value === '' ? null : e.target.value)}
      state={state}
    />
  );
};
