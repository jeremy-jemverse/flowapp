import type { FC } from 'react';
import type { ValueSelectorProps } from '~/components/query-builder/ValueSelectors/types.ts';
import { TextInput } from '@ecainternational/eca-components';
import { useValidation } from '~/components/query-builder/ValueSelectors/use-validation.ts';

export const DateField: FC<ValueSelectorProps<string>> = ({ name, title, value, onChange }) => {
  const { state } = useValidation('date', value);
  return (
    <TextInput
      name={name}
      title={title}
      value={value ?? ''}
      type="date"
      className={'!w-40'}
      onChange={(e) => onChange(e.target.value === '' ? null : e.target.value)}
      state={state}
    />
  );
};
