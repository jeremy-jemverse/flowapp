import type { FC } from 'react';
import type { ValueSelectorProps } from '~/components/query-builder/ValueSelectors/types.ts';
import { useTranslation } from 'react-i18next';
import { Select } from '@ecainternational/eca-components';
import { useValidation } from '~/components/query-builder/ValueSelectors/use-validation.ts';

export const BooleanField: FC<ValueSelectorProps<boolean>> = ({ name, title, value, onChange }) => {
  const { t } = useTranslation();
  const { state } = useValidation('boolean', value);
  return (
    <Select
      name={name}
      title={title}
      value={value == null ? '' : value ? 'true' : 'false'}
      className={'!w-[186px]'}
      onChange={(event) => {
        const value = event.target.value;
        onChange(value === 'true' ? true : value === 'false' ? false : null);
      }}
      state={state}
    >
      <option value="">{t('globalVariables.rule.selectPlaceholder')}</option>
      <option value="true">Yes</option>
      <option value="false">No</option>
    </Select>
  );
};
