import type { FC } from 'react';
import { useMemo } from 'react';
import type { ActionWidgetProps, Field } from '~/components/query-builder/types.ts';
import { FieldType, ValueFieldSource } from '~/components/query-builder/types.ts';
import FieldSelector from '~/components/query-builder/FieldSelector.tsx';
import { useQueryBuilder } from '~/components/query-builder/QueryBuilderContext.tsx';
import { getFieldType } from '~/components/query-builder/utils.ts';
import { z } from 'zod';
import { refineFieldValues } from '~/components/query-builder/schemas.ts';
import ValueField from '~/components/query-builder/ValueField.tsx';

type SetVariableConfig = {
  field: string;
  fieldSrc: string;
  value: any[];
  valueSrc: ValueFieldSource[];
  valueType: FieldType[];
};
export const SetVariable: FC<ActionWidgetProps> = ({ action, onChange }) => {
  const { fields } = useQueryBuilder();

  const setVariableConfig = action.config as SetVariableConfig;

  const field = useMemo(
    () => fields.find((field) => field.id === setVariableConfig.field),
    [fields, setVariableConfig.field],
  );

  const handleFieldSelect = (selectedField: Field) => {
    const type = getFieldType(selectedField);
    const config = {
      ...setVariableConfig,
      field: selectedField.id,
      fieldSrc: 'field',
      value: [null],
      valueSrc: ['value'],
      valueType: [type],
    };
    onChange({
      ...action,
      config,
    });
  };

  const handleValueChange = (value: any, source: ValueFieldSource, type: FieldType | null) => {
    const config = { ...setVariableConfig, value: [value], valueSrc: [source], valueType: [type] } as SetVariableConfig;
    onChange({
      ...action,
      config,
    });
  };

  return (
    <div className="flex items-center gap-2">
      <FieldSelector value={field} onChange={handleFieldSelect} />
      {field && (
        <>
          <span>=</span>
          <ValueField
            id={action.id}
            enableValueSource
            type={setVariableConfig.valueType[0]}
            source={setVariableConfig.valueSrc[0]}
            value={setVariableConfig.value[0]}
            onChange={handleValueChange}
            options={field?.options}
          />
        </>
      )}
    </div>
  );
};

export const setVariableSchema = z.object({
  id: z.string(),
  type: z.literal('setVariable'),
  config: z
    .object({
      field: z.string(),
      fieldSrc: ValueFieldSource,
      value: z.any().array(),
      valueSrc: ValueFieldSource.array(),
      valueType: FieldType.array(),
    })
    .superRefine((val, ctx) => {
      const { value: values, valueType: valueTypes, valueSrc: valueSources } = val;
      refineFieldValues(values, valueTypes, valueSources, ctx);
    }),
});
