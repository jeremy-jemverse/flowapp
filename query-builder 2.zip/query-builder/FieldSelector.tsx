import type { FC } from 'react';
import React, { useState, useMemo } from 'react';
import Modal from '~/components/modal/modal.tsx';
import { Button, Chip, FieldSet, TextInput } from '@ecainternational/eca-components';
import clsx from 'clsx';
import type { Field, FieldType } from '~/components/query-builder/types.ts';
import { useTranslation } from 'react-i18next';
import { useQueryBuilder } from '~/components/query-builder/QueryBuilderContext.tsx';
import { getFieldType } from '~/components/query-builder/utils.ts';

interface FieldSelectorProps {
  value?: Field;
  typeFilter?: FieldType | null;
  onChange: (field: Field) => void;
}
const FieldSelector: FC<FieldSelectorProps> = ({ value, typeFilter, onChange }) => {
  const { t } = useTranslation();
  const { fields } = useQueryBuilder();
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const filteredFields = useMemo(() => {
    let filteredFields = [...fields];
    if (typeFilter) {
      filteredFields = filteredFields.filter((f) => getFieldType(f) === typeFilter);
    }
    if (selectedCategory) {
      filteredFields = filteredFields.filter((f) => f.category === selectedCategory);
    }
    if (searchTerm !== '') {
      filteredFields = filteredFields.filter(
        (f) =>
          f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          f.description?.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }
    return filteredFields;
  }, [fields, searchTerm, selectedCategory, typeFilter]);
  const categories = Array.from(new Set(fields.map((f) => f.category).filter((f) => f !== undefined)));
  const handleChange = (field: Field) => {
    onChange(field);
    setIsOpen(false);
  };
  const closeModal = () => {
    setSearchTerm('');
    setSelectedCategory(null);
  };

  return (
    <>
      <div className="relative flex w-min max-w-[200px]">
        <button
          onClick={() => setIsOpen(true)}
          title={t('globalVariables.rule.field')}
          className={clsx(
            'text-neutral-body outline-default-transparent paragraph-sm-mid border-controls-border bg-neutral-layer-1 cursor-default truncate ps-3',
            'flex w-full appearance-none items-center rounded-md border py-3 pe-16 outline outline-2 outline-offset-2 transition',
            'disabled:border-neutral-detail-paler disabled:bg-neutral-layer-1 disabled:text-controls-content-disabled  disabled:cursor-not-allowed disabled:outline-0',
            'hover:outline-neutral-detail-paler hover:focus-within:outline-controls-highlight focus-within:border-controls-highlight focus-within:outline-controls-highlight',
            !value &&
              'border-states-error bg-neutral-layer-1 hover:border-states-error hover:outline-states-error-paler focus-within:outline-states-error hover:focus-within:outline-states-error',
          )}
          type="button"
          aria-haspopup="true"
        >
          {value?.name || t('globalVariables.rule.selectField')}
        </button>
        <div className={`pointer-events-none absolute right-1.5 top-0 flex h-full items-center`}>
          {!value && <i className="fi fi-rr-exclamation text-states-error flex items-center" />}
          <i className="fi fi-sr-angle-small-down flex items-center px-1.5" />
        </div>
      </div>
      <Modal isOpen={isOpen} setIsOpen={setIsOpen} onClose={closeModal} className="!w-[600px] max-w-none">
        <div className="mt-3 flex flex-col gap-4">
          <FieldSet className="">
            <TextInput
              icon="fi-rr-search"
              name="search"
              aria-label={t('globalVariables.rule.searchVariables')}
              id="search"
              type="search"
              variant="tonal"
              placeholder={t('globalVariables.rule.searchVariables')}
              value={searchTerm}
              data-autofocus
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </FieldSet>
          <ul className="flex gap-2">
            {[null, ...categories].map((category) => {
              return (
                <li key={category ?? 'All'}>
                  <Chip
                    label={category ?? 'All'}
                    size="small"
                    variant={selectedCategory === category ? 'vis-5' : 'neutral'}
                    onClick={() => setSelectedCategory(category)}
                    className={selectedCategory === category ? 'cursor-default' : 'cursor-pointer'}
                  />
                </li>
              );
            })}
          </ul>
          <ul className="flex max-h-80 flex-col gap-2 overflow-y-auto pe-2">
            {filteredFields.map((field) => (
              <li key={field.id}>
                <Button
                  className="align-start flex w-full flex-col justify-start gap-3"
                  onClick={() => handleChange(field)}
                  variant="ghost"
                  type="button"
                  name="selectField"
                >
                  <div className="flex w-full items-start justify-between">
                    <span className="heading-xs-mid text-neutral-detail-bolder">{field.name}</span>
                    <Chip label={getFieldType(field) ?? 'unknown'} size="small" variant="vis-5" />
                  </div>
                  <p className="paragraph-sm-mid text-neutral-detail-bolder self-start text-sm">{field.description}</p>
                </Button>
              </li>
            ))}
          </ul>
        </div>
      </Modal>
    </>
  );
};

export default FieldSelector;
