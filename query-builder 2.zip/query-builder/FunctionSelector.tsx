import type { FC } from 'react';
import React, { useState, useMemo } from 'react';
import Modal from '~/components/modal/modal.tsx';
import { Alert, Button, Chip, FieldSet, TextInput } from '@ecainternational/eca-components';
import clsx from 'clsx';
import type { FieldType, FuncArg } from '~/components/query-builder/types.ts';
import { useTranslation } from 'react-i18next';
import { FUNCTIONS } from '~/components/query-builder/config.ts';

interface FuncConfigView {
  id: string;
  name: string;
  description: string;
  arguments: FuncArg[];
  returnType: FieldType;
}
interface FunctionSelectorProps {
  value?: string;
  typeFilter?: FieldType | null;
  onChange: (value: unknown, type: FieldType) => void;
}
const FunctionSelector: FC<FunctionSelectorProps> = ({ value, typeFilter, onChange }) => {
  const { t } = useTranslation();
  const functions = useMemo(
    () =>
      Object.keys(FUNCTIONS).map((key: string) => {
        const func = FUNCTIONS[key];
        return {
          id: key,
          name: func.name,
          description: func.description,
          arguments: func.arguments,
          returnType: func.returnType,
        } as FuncConfigView;
      }),
    [],
  );
  const func = value ? FUNCTIONS[value] : null;
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const filteredFunctions = useMemo(() => {
    let filteredFunctions = [...functions];
    if (typeFilter) {
      filteredFunctions = filteredFunctions.filter((f) => f.returnType === typeFilter);
    }
    if (searchTerm !== '') {
      filteredFunctions = filteredFunctions.filter(
        (f) =>
          f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          f.description?.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }
    return filteredFunctions;
  }, [functions, searchTerm, typeFilter]);
  const handleChange = (id: string) => {
    const func = FUNCTIONS[id];
    onChange({ func: id, args: func.defaultArgs }, func.returnType);
    setIsOpen(false);
  };
  const closeModal = () => {
    setSearchTerm('');
  };

  return (
    <>
      <div className="relative flex w-min max-w-[200px]">
        <button
          onClick={() => setIsOpen(true)}
          title={t('globalVariables.rule.field')}
          className={clsx(
            'text-neutral-body outline-default-transparent paragraph-sm-mid border-controls-border bg-neutral-layer-1 cursor-default truncate ps-3',
            'flex w-full appearance-none items-center rounded-md border py-3 pe-16 outline outline-2 outline-offset-2 transition',
            'disabled:border-neutral-detail-paler disabled:bg-neutral-layer-1 disabled:text-controls-content-disabled  disabled:cursor-not-allowed disabled:outline-0',
            'hover:outline-neutral-detail-paler hover:focus-within:outline-controls-highlight focus-within:border-controls-highlight focus-within:outline-controls-highlight',
            !value &&
              'border-states-error bg-neutral-layer-1 hover:border-states-error hover:outline-states-error-paler focus-within:outline-states-error hover:focus-within:outline-states-error',
          )}
          type="button"
          aria-haspopup="true"
        >
          {func?.name || t('globalVariables.rule.selectFunction')}
        </button>
        <div className={`pointer-events-none absolute right-1.5 top-0 flex h-full items-center`}>
          {!func && <i className="fi fi-rr-exclamation text-states-error flex items-center" />}
          <i className="fi fi-sr-angle-small-down flex items-center px-1.5" />
        </div>
      </div>
      <Modal isOpen={isOpen} setIsOpen={setIsOpen} onClose={closeModal} className="!w-[600px] max-w-none">
        <div className="mt-3 flex flex-col gap-4">
          <FieldSet className="">
            <TextInput
              icon="fi-rr-search"
              name="search"
              aria-label={t('globalVariables.rule.searchFunctions')}
              id="search"
              type="search"
              variant="tonal"
              placeholder={t('globalVariables.rule.searchFunctions')}
              value={searchTerm}
              data-autofocus
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </FieldSet>
          {filteredFunctions.length === 0 && <Alert variant="warning" label={t('globalVariables.rule.noFunctions')} />}
          <ul className="flex max-h-80 flex-col gap-2 overflow-y-auto">
            {filteredFunctions.map((func) => (
              <li key={func.id}>
                <Button
                  className="bg-neutral-layer-2 w-full"
                  onClick={() => handleChange(func.id)}
                  variant="ghost"
                  type="button"
                  name="selectField"
                >
                  <div className="flex w-full flex-col items-start gap-3">
                    <div className="flex w-full items-start justify-between">
                      <span className="heading-xs-mid  text-visualisation-5-main">{func.name}</span>
                      <Chip label={func.returnType} size="small" variant="vis-5" />
                    </div>
                    <div className="paragraph-sm-mid text-neutral-detail-bolder flex flex-col items-start gap-2 text-sm">
                      <div>{t(func.description)}</div>
                      {func.arguments.length ? (
                        <div className="flex flex-col items-start gap-1 text-xs">
                          <span>{t('globalVariables.rule.arguments')}</span>
                          <ul className="ms-6 flex flex-col items-start">
                            {func.arguments.map((arg) => (
                              <li key={arg.name}>
                                {arg.name}: {arg.type} - {t(arg.description)}
                              </li>
                            ))}
                          </ul>
                        </div>
                      ) : null}
                    </div>
                  </div>
                </Button>
              </li>
            ))}
          </ul>
        </div>
      </Modal>
    </>
  );
};

export default FunctionSelector;
