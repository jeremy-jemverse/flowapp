import type { FC } from 'react';
import React from 'react';
import type { SwitchGroup, CaseGroup, Action } from '~/components/query-builder/types.ts';
import ConditionBuilder from '~/components/query-builder/ConditionBuilder.tsx';
import clsx from 'clsx';
import { useTranslation } from 'react-i18next';
import ActionSelector from '~/components/query-builder/ActionSelector.tsx';
import ActionBuilder from './ActionBuilder';
import { createNewAction, createNewCaseGroup } from '~/components/query-builder/utils.ts';

interface SwitchQueryProps {
  query: SwitchGroup;
  onChange: (query: SwitchGroup) => void;
}

const getDefaultCase = (switchGroup: SwitchGroup) => {
  const lastCase = switchGroup.children1.length === 0 ? null : switchGroup.children1[switchGroup.children1.length - 1];
  return lastCase?.children1 == undefined ? lastCase : null;
};
const SwitchGroupBuilder: FC<SwitchQueryProps> = ({ query, onChange }) => {
  const { t } = useTranslation();
  const defaultCase = getDefaultCase(query);

  const handleChangeCase = (index: number, updatedCase: CaseGroup) => {
    const cases = [...query.children1];
    cases[index] = updatedCase;
    onChange({ ...query, children1: cases });
  };

  const handleAddCase = () => {
    let children1 = [...query.children1];
    const newCase = createNewCaseGroup();
    if (defaultCase) {
      children1.splice(children1.length - 1, 0, newCase);
    } else {
      children1.push(newCase);
    }
    onChange({
      ...query,
      children1,
    });
  };

  const handleDeleteCase = (index: number) => {
    const cases = query.children1.filter((_, i) => i !== index);
    onChange({ ...query, children1: cases });
  };

  const handleChangeDefaultAction = (index: number, updatedAction: Action) => {
    if (!defaultCase) return;
    const defaultActions = [...defaultCase.properties.actions];
    defaultActions[index] = updatedAction;
    const updatedDefaultCase = { ...defaultCase, properties: { ...defaultCase.properties, actions: defaultActions } };
    handleChangeCase(query.children1.length - 1, updatedDefaultCase);
  };

  const handleAddDefaultAction = (type: string, config: unknown) => {
    const newAction = createNewAction(type, config);
    if (defaultCase) {
      const defaultActions = [...defaultCase.properties.actions, newAction];
      const updatedDefaultCase = { ...defaultCase, properties: { ...defaultCase.properties, actions: defaultActions } };
      handleChangeCase(query.children1.length - 1, updatedDefaultCase);
    } else {
      const newCaseGroup = createNewCaseGroup();
      delete newCaseGroup.children1;
      newCaseGroup.properties.actions = [newAction];
      onChange({
        ...query,
        children1: [...query.children1, newCaseGroup],
      });
    }
  };

  const handleDeleteDefaultAction = (index: number) => {
    if (!defaultCase) return;
    const defaultActions = defaultCase.properties.actions.filter((_, i) => i !== index);
    if (defaultActions.length === 0) {
      handleDeleteCase(query.children1.length - 1);
    } else {
      const updatedDefaultCase = { ...defaultCase, properties: { ...defaultCase.properties, actions: defaultActions } };
      handleChangeCase(query.children1.length - 1, updatedDefaultCase);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      {query.children1.map((condition, index) => {
        if (condition.children1 == undefined) return null;
        return (
          <ConditionBuilder
            key={condition.id}
            condition={condition}
            index={index}
            onChange={(update) => handleChangeCase(index, update)}
            onDelete={() => handleDeleteCase(index)}
          />
        );
      })}

      <button
        onClick={handleAddCase}
        className={clsx(
          'bg-neutral-layer-2 label-sm-mid flex items-center justify-center gap-3 rounded-lg px-2 py-3',
          'hover:bg-neutral-layer-3',
        )}
        type="button"
      >
        <i className="file: fi-rr-plus flex" aria-hidden />
        <span>{t('globalVariables.rule.addCase')}</span>
      </button>

      <div className="bg-neutral-layer-2 flex flex-col gap-3 rounded-lg p-4">
        <div className="heading-sm-mid text-neutral-body">{t('globalVariables.rule.defaultActionsHeading')}</div>
        <p className="paragraph-sm-mid">{t('globalVariables.rule.defaultActionsDescription')}</p>
        {defaultCase?.properties.actions.map((action, index) => (
          <ActionBuilder
            key={action.id}
            index={index}
            action={action}
            onChange={(update) => handleChangeDefaultAction(index, update)}
            onDelete={() => handleDeleteDefaultAction(index)}
          />
        ))}
        <ActionSelector onAdd={handleAddDefaultAction} />
      </div>
    </div>
  );
};

export default SwitchGroupBuilder;
