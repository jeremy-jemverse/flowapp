import { Button, IconButton } from '@ecainternational/eca-components';
import type { FC } from 'react';
import React from 'react';
import CombinatorSelector from '~/components/query-builder/CombinatorSelector.tsx';
import type { Combinator, Rule, RuleGroup, RuleGroupProperties } from '~/components/query-builder/types.ts';
import RuleBuilder from '~/components/query-builder/RuleBuilder.tsx';
import { createNewRule, createNewRuleGroup } from '~/components/query-builder/utils.ts';
import { useTranslation } from 'react-i18next';
import { useQueryBuilder } from '~/components/query-builder/QueryBuilderContext.tsx';

interface RuleGroupBuilderProps {
  group: RuleGroup;
  onChange: (group: RuleGroup) => void;
  onDelete?: () => void;
  isRoot?: boolean;
}
const RuleGroupBuilder: FC<RuleGroupBuilderProps> = ({ group, onChange, onDelete, isRoot }) => {
  const { fields } = useQueryBuilder();
  const { t } = useTranslation();

  const { properties, children1 } = group;
  const handleCombinatorChange = (combinator: Combinator) => {
    const properties: RuleGroupProperties = { ...group.properties, conjunction: combinator };
    onChange({ ...group, properties });
  };

  const handleAdd = (ruleOrGroup: Rule | RuleGroup) => {
    onChange({
      ...group,
      children1: [...group.children1, ruleOrGroup],
    });
  };

  const handleRuleChange = (index: number, updatedRule: Rule | RuleGroup) => {
    const rules = [...group.children1];
    rules[index] = updatedRule;
    onChange({ ...group, children1: rules });
  };

  const handleDelete = (index: number) => {
    const rules = group.children1.filter((_, i) => i !== index);
    onChange({ ...group, children1: rules });
  };

  const borderColor =
    group.properties.conjunction === 'or' ? 'border-s-visualisation-5-main' : 'border-s-controls-highlight ';

  return (
    <div className={`flex flex-col gap-3 ${borderColor} border-s-2 ps-4`}>
      <div className="flex items-center justify-start gap-2">
        <CombinatorSelector id={group.id} combinator={properties.conjunction} onChange={handleCombinatorChange} />
        {!isRoot && (
          <IconButton
            name="deleteGroup"
            title={t('globalVariables.rule.deleteGroup')}
            aria-label={t('globalVariables.rule.deleteGroup')}
            variant="standard"
            icon="fi-rr-trash"
            size="xsmall"
            onClick={onDelete}
            className="focus-visible:text-states-error hover:text-states-error"
          />
        )}
      </div>
      {children1.map((child, index) =>
        child.type == 'group' ? (
          <RuleGroupBuilder
            key={child.id}
            group={child as RuleGroup}
            onChange={(group) => handleRuleChange(index, group)}
            onDelete={() => handleDelete(index)}
          />
        ) : (
          <RuleBuilder
            key={child.id}
            rule={child as Rule}
            onChange={(rule) => handleRuleChange(index, rule)}
            onDelete={() => handleDelete(index)}
          />
        ),
      )}
      <div className="flex justify-start gap-2">
        <Button
          name="addRule"
          variant="ghost"
          className="flex items-center gap-1"
          size="small"
          onClick={() => handleAdd(createNewRule(fields[0]))}
        >
          <i className="fr fi-rr-add flex" aria-hidden />
          <span>{t('globalVariables.rule.addRule')}</span>
        </Button>
        <Button
          name="addGroup"
          variant="ghost"
          className="flex items-center gap-1"
          size="small"
          onClick={() => handleAdd(createNewRuleGroup())}
        >
          <i className="fr fi-rr-family flex" aria-hidden />
          <span>{t('globalVariables.rule.addGroup')}</span>
        </Button>
      </div>
    </div>
  );
};

export default RuleGroupBuilder;
