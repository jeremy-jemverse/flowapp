import type {
  Action,
  CaseGroup,
  Field,
  FieldType,
  Operator,
  Rule,
  RuleGroup,
  SwitchGroup,
} from '~/components/query-builder/types.ts';
import { BASE_OPERATORS, TYPE_OPERATORS } from '~/components/query-builder/config.ts';
import { v4 as uuidv4 } from 'uuid';

export const getOperatorsByType = (type: FieldType | null) => {
  return TYPE_OPERATORS[type ?? 'text'] ?? BASE_OPERATORS;
};

export const getDefaultValueByOperator = (operator: Operator) => {
  switch (operator) {
    case 'in':
    case 'not_in':
      return [null];
    case 'between':
    case 'not_between':
      return [null, null];
    default:
      return [null];
  }
};

export const getFieldType = (field: Field) => {
  return (field.metadata?.resultType ?? field.type)?.toLowerCase() as FieldType;
};

export const getValueType = (type: FieldType | null, operator: Operator) => {
  return operator === 'in' || operator === 'not_in' ? 'multiselect' : type;
};

export const createNewRuleGroup = (): RuleGroup => {
  return {
    id: uuidv4(),
    type: 'group',
    properties: { conjunction: 'and' },
    children1: [],
  };
};

export const createNewSwitchGroup = () => {
  return {
    type: 'switch_group',
    id: uuidv4(),
    children1: [],
    properties: {},
  } as SwitchGroup;
};

export const createNewCaseGroup = (): CaseGroup => {
  return {
    id: uuidv4(),
    type: 'case_group',
    properties: { conjunction: 'and', actions: [] },
    children1: [],
  };
};

export const createNewRule = (field: Field): Rule => {
  const type = getFieldType(field);
  const operator = getOperatorsByType(type)[0];
  return {
    id: uuidv4(),
    type: 'rule',
    properties: {
      field: field.id,
      fieldSrc: 'field',
      operator,
      value: [null],
      valueSrc: ['value'],
      valueType: [getValueType(type, operator)],
    },
  };
};

export const createNewAction = (type: string, config: unknown) => {
  return {
    id: uuidv4(),
    type,
    config,
  } as Action;
};
