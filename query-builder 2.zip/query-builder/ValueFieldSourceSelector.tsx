import { Menu, MenuButton, MenuItem, MenuItems } from '@ecainternational/eca-components';
import clsx from 'clsx';
import type { FC } from 'react';
import type { ValueFieldSource } from '~/components/query-builder/types.ts';
import { useTranslation } from 'react-i18next';

interface ValueFieldSourceSelectorProps {
  enableValueSource?: boolean;
  onChange: (source: ValueFieldSource) => void;
  source: ValueFieldSource;
}

const ValueFieldSourceSelector: FC<ValueFieldSourceSelectorProps> = ({ enableValueSource, onChange, source }) => {
  const { t } = useTranslation();
  const availableSources: Record<ValueFieldSource, { label: string; icon: string; enabled: boolean }> = {
    value: { label: t('globalVariables.rule.value'), icon: '#', enabled: enableValueSource ?? false },
    field: { label: t('globalVariables.rule.field'), icon: '<>', enabled: true },
    func: { label: t('globalVariables.rule.function'), icon: '(x)', enabled: true },
  };
  const currentSourceConfig = availableSources[source];
  return (
    <Menu className="flex justify-center">
      <MenuButton
        as="button"
        className={clsx(
          'bg-neutral-layer-2 label-sm-mid mx-auto flex w-full max-w-96 items-center justify-center gap-3 rounded-lg px-2 py-3',
          'hover:bg-neutral-layer-3',
        )}
      >
        <span className="flex w-4 items-center justify-center">{currentSourceConfig.icon}</span>
      </MenuButton>
      <MenuItems anchor="bottom start" className="z-10">
        {Object.keys(availableSources).map((source) => {
          const config = availableSources[source as ValueFieldSource];
          return (
            config.enabled && (
              <MenuItem>
                <button className="flex w-full items-center gap-2" onClick={() => onChange(source as ValueFieldSource)}>
                  <span>{config.icon}</span>
                  <span>{config.label}</span>
                </button>
              </MenuItem>
            )
          );
        })}
      </MenuItems>
    </Menu>
  );
};

export default ValueFieldSourceSelector;
