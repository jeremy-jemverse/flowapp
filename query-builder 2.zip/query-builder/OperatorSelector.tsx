import type { FC } from 'react';
import React from 'react';
import type { FieldType, Operator } from '~/components/query-builder/types.ts';
import './QueryBuilder.css';
import { useTranslation } from 'react-i18next';
import { Select } from '@ecainternational/eca-components';
import { OPERATOR_LABELS } from '~/components/query-builder/config.ts';
import { getOperatorsByType } from '~/components/query-builder/utils.ts';

interface OperatorSelectorProps {
  type: FieldType;
  operator: Operator;
  onChange: (operator: Operator) => void;
}
const OperatorSelector: FC<OperatorSelectorProps> = ({ type, operator, onChange }) => {
  const { t } = useTranslation();
  const operators = getOperatorsByType(type);

  return (
    <Select
      value={operator}
      title={t('globalVariables.rule.operator')}
      className="!w-40"
      onChange={(event) => onChange(event.target.value as Operator)}
    >
      {operators.map((operator) => (
        <option key={operator} value={operator}>
          {OPERATOR_LABELS[operator] ?? operator}
        </option>
      ))}
    </Select>
  );
};

export default OperatorSelector;
