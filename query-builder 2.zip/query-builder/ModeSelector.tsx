import type { FC } from 'react';
import type { QueryMode } from '~/components/query-builder/types.ts';
import './QueryBuilder.css';
import { useTranslation } from 'react-i18next';

interface ModeSelectorProps {
  mode: QueryMode;
  onChange: (mode: QueryMode) => void;
}
const ModeSelector: FC<ModeSelectorProps> = ({ mode, onChange }) => {
  const { t } = useTranslation();

  return (
    <fieldset
      className="bg-neutral-layer-2 flex gap-2 rounded-lg p-1"
      role="radiogroup"
      aria-label={t('globalVariables.rule.selectQueryMode')}
    >
      <ModeInput
        mode="group"
        onChange={onChange}
        checked={mode === 'group'}
        label={t('globalVariables.rule.logicMode')}
      />
      <ModeInput
        mode="switch_group"
        onChange={onChange}
        checked={mode === 'switch_group'}
        label={t('globalVariables.rule.switchMode')}
      />
    </fieldset>
  );
};

interface ModeInputProps {
  checked: boolean;
  label: string;
  mode: QueryMode;
  onChange: (mode: QueryMode) => void;
}
const ModeInput: FC<ModeInputProps> = ({ checked, label, mode, onChange }) => {
  return (
    <label
      className={`label-sm-mid rounded-md px-4 py-2 text-sm has-[:focus-visible]:outline ${
        checked ? 'bg-primary-main text-primary-text-1 ' : 'cursor-pointer'
      }`}
    >
      <input
        type="radio"
        name="mode"
        value={mode}
        checked={checked}
        onChange={(event) => onChange(event.target.value as QueryMode)}
        className="appearance-none"
      />
      <span>{label}</span>
    </label>
  );
};

export default ModeSelector;
