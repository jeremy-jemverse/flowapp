import type { ActionConfig, FieldType, FuncConfig, Operator } from './types.ts';
import { ValueFieldSource } from './types.ts';
import type { FC } from 'react';
import type { ValueSelectorProps } from '~/components/query-builder/ValueSelectors/types.ts';
import {
  BooleanField,
  DateField,
  NumberField,
  PercentageField,
  SelectField,
  TextField,
  TimeField,
} from '~/components/query-builder/ValueSelectors';
import { SetVariable } from '~/components/query-builder/ActionWidgets';
import { MultiSelectField } from '~/components/query-builder/ValueSelectors/MultiSelectField.tsx';
import { PercentageOf } from '~/components/query-builder/FunctionWidgets';
import { z } from 'zod';
import { refineActionValue } from '~/components/query-builder/schemas.ts';

export const BASE_OPERATORS: Operator[] = ['==', '!=', 'is_empty', 'is_not_empty'];
export const TYPE_OPERATORS: Record<FieldType, Operator[]> = {
  number: [...BASE_OPERATORS, '>', '<', '>=', '<=', 'between', 'not_between'],
  percentage: [...BASE_OPERATORS, '>', '<', '>=', '<=', 'between', 'not_between'],
  text: [...BASE_OPERATORS, 'contains', 'not_contains', 'starts_with', 'ends_with'],
  boolean: ['==', '!='],
  select: [...BASE_OPERATORS, 'in', 'not_in'],
  multiselect: ['is_empty', 'is_not_empty', 'in', 'not_in'],
  date: [...BASE_OPERATORS, '>', '<', '>=', '<=', 'between', 'not_between'],
  time: [...BASE_OPERATORS, '>', '<', '>=', '<=', 'between', 'not_between'],
};
export const OPERATOR_LABELS: Record<Operator, string> = {
  '==': 'Equals',
  '!=': 'Not equals',
  '>': 'Greater than',
  '<': 'Less than',
  '>=': 'Greater than or equal',
  '<=': 'Less than or equal',
  between: 'Between',
  not_between: 'Not between',
  in: 'In',
  not_in: 'Not in',
  contains: 'Contains',
  not_contains: 'Does not contain',
  starts_with: 'Starts with',
  ends_with: 'Ends with',
  is_empty: 'Is empty',
  is_not_empty: 'Is not empty',
};

export const BASIC_RENDERERS: Record<string, FC<ValueSelectorProps>> = {
  boolean: BooleanField,
  number: NumberField,
  percentage: PercentageField,
  date: DateField,
  time: TimeField,
  text: TextField,
  select: SelectField,
  multiselect: MultiSelectField,
};

export const ACTIONS: Record<string, ActionConfig> = {
  setVariable: {
    label: 'globalVariables.rule.actions.setVariable',
    icon: 'fi-rr-arrow-down-to-square',
    widget: SetVariable,
    defaultConfig: { value: [null], valueSrc: [null], valueType: [null], field: null, fieldSrc: null },
  },
};

export const FUNCTIONS: Record<string, FuncConfig> = {
  currentDate: {
    name: 'CURRENT_DATE',
    description: 'globalVariables.functions.currentDate.description',
    arguments: [],
    widget: null,
    schema: z.object({ func: z.literal('currentDate'), args: z.null() }),
    returnType: 'date',
    defaultArgs: null,
  },
  percentageOf: {
    name: 'PERCENTAGE_OF',
    description: 'globalVariables.functions.percentageOf.description',
    arguments: [
      {
        name: 'percentage',
        type: 'percentage',
        description: 'globalVariables.functions.percentageOf.arg1',
      },
      {
        name: 'totalAmount',
        type: 'number',
        description: 'globalVariables.functions.percentageOf.arg2',
      },
    ],
    widget: PercentageOf,
    schema: z.object({
      func: z.literal('percentageOf'),
      args: z.object({
        percentage: z
          .object({
            value: z.any(),
            valueSrc: ValueFieldSource,
          })
          .superRefine((data, ctx) => refineActionValue(data.value, 'number', data.valueSrc, ctx)),
        totalAmount: z
          .object({
            value: z.any(),
            valueSrc: ValueFieldSource,
          })
          .superRefine((data, ctx) => refineActionValue(data.value, 'number', data.valueSrc, ctx)),
      }),
    }),
    returnType: 'number',
    defaultArgs: {
      percentage: {
        value: null,
        valueSrc: 'value',
      },
      totalAmount: {
        value: null,
        valueSrc: 'value',
      },
    },
  },
};
