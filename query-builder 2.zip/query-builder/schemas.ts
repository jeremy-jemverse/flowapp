import { Combinator, FieldType, Operator, ValueFieldSource } from '~/components/query-builder/types.ts';
import type { RefinementCtx, ZodType } from 'zod';
import { z } from 'zod';
import { setVariableSchema } from '~/components/query-builder/ActionWidgets';
import { FUNCTIONS } from '~/components/query-builder/config.ts';

export const valueSchemas: Record<FieldType, ZodType<unknown>> = {
  text: z.string(),
  number: z.number(),
  date: z.string().date(),
  time: z.string().time(),
  boolean: z.boolean(),
  select: z.string(),
  multiselect: z.array(z.string()),
  percentage: z.number(),
};

export const refineActionValue = (
  value: unknown,
  valueType: FieldType | null,
  valueSource: ValueFieldSource,
  ctx: RefinementCtx,
) => {
  refineFieldValues([value], [valueType], [valueSource], ctx);
};
export const refineFieldValues = (
  values: unknown[],
  valueTypes: (FieldType | null)[],
  valueSources: ValueFieldSource[],
  ctx: RefinementCtx,
) => {
  for (let i = 0; i < values.length; i++) {
    const type = valueTypes[i];
    const value = values[i];
    const source = valueSources[i];
    let valueSchema: ZodType = z.NEVER;
    switch (source) {
      case 'field':
        valueSchema = z.string();
        break;
      case 'value':
        valueSchema = type ? valueSchemas[type] : z.NEVER;
        break;
      case 'func':
        valueSchema = z.union([FUNCTIONS.percentageOf.schema, FUNCTIONS.percentageOf.schema]);
        break;
    }
    const result = valueSchema.safeParse(value);
    if (!result.success) {
      ctx.addIssue(result.error.issues[0]);
    }
  }
};

const ruleSchema = z.object({
  id: z.string(),
  type: z.literal('rule'),
  properties: z
    .object({
      field: z.any(),
      fieldSrc: ValueFieldSource,
      operator: Operator,
      value: z.any().array(),
      valueSrc: ValueFieldSource.array(),
      valueType: FieldType.array(),
    })
    .superRefine((val, ctx) => {
      const { value: values, valueType: valueTypes, valueSrc: valueSources, operator, field, fieldSrc } = val;
      refineFieldValues([field], [null], [fieldSrc], ctx);
      if (operator === 'is_empty' || operator === 'is_not_empty') {
        const result = z.array(z.null()).length(1).safeParse(values);
        if (!result.success) {
          ctx.addIssue(result.error.issues[0]);
        }
        // No value to validate
        return z.NEVER;
      }

      if (operator === 'between' || operator === 'not_between') {
        const result = z.array(z.any()).length(2).safeParse(values);
        if (!result.success) {
          ctx.addIssue(result.error.issues[0]);
          return z.NEVER;
        }
      }

      refineFieldValues(values, valueTypes, valueSources, ctx);
    }),
});

const ruleGroupSchema: ZodType<unknown> = z.lazy(() =>
  z.object({
    id: z.string(),
    type: z.literal('group'),
    properties: z.object({
      conjunction: Combinator,
    }),
    children1: z.union([ruleSchema, ruleGroupSchema]).array().nonempty(),
  }),
);

const caseGroupSchema: ZodType<unknown> = z.lazy(() =>
  z.object({
    id: z.string(),
    type: z.literal('case_group'),
    properties: z.object({
      conjunction: Combinator,
      actions: setVariableSchema.array(),
    }),
    children1: z.union([ruleSchema, ruleGroupSchema]).array().nonempty().optional(),
  }),
);

const switchGroupSchema = z.object({
  id: z.string(),
  type: z.literal('switch_group'),
  properties: z.object({}),
  children1: caseGroupSchema.array().nonempty(),
});

export const querySchema = z.union([ruleGroupSchema, switchGroupSchema]);
