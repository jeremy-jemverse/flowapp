import type { FieldType, ValueFieldSource } from '~/components/query-builder/types.ts';
import type { FC } from 'react';
import { useMemo } from 'react';
import { BASIC_RENDERERS, FUNCTIONS } from '~/components/query-builder/config.ts';
import { TextField } from '~/components/query-builder/ValueSelectors';
import type { ValueSelectorProps } from '~/components/query-builder/ValueSelectors/types.ts';
import FieldSelector from '~/components/query-builder/FieldSelector.tsx';
import { useQueryBuilder } from '~/components/query-builder/QueryBuilderContext.tsx';
import { getFieldType } from '~/components/query-builder/utils.ts';
import ValueFieldSourceSelector from './ValueFieldSourceSelector';
import { useTranslation } from 'react-i18next';
import FunctionSelector from '~/components/query-builder/FunctionSelector.tsx';

type ValueFieldProps = {
  id: string;
  type: FieldType | null;
  source: ValueFieldSource;
  value: any;
  options?: { value: string; label: string }[];
  onChange: (value: any, source: ValueFieldSource, type: FieldType | null) => void;
  enableValueSource?: boolean;
};

const ValueField: FC<ValueFieldProps> = ({ id, type, source, value, options, onChange, enableValueSource }) => {
  const { fields } = useQueryBuilder();
  const { t } = useTranslation();
  const field = useMemo(
    () => (source === 'field' ? fields.find((field) => field.id === value) : undefined),
    [fields, value, source],
  );
  let component = null;

  switch (source) {
    case 'field':
      component = (
        <FieldSelector
          typeFilter={type}
          value={field}
          onChange={(updatedField) => onChange(updatedField.id, 'field', getFieldType(updatedField))}
        />
      );
      break;
    case 'value':
      const componentProps = {
        value,
        options,
        name: `${id}_value`,
        title: t('globalVariables.rule.value'),
      };
      let FieldToRender: FC<ValueSelectorProps> = BASIC_RENDERERS[type ?? 'text'] ?? TextField;
      component = (
        <FieldToRender {...componentProps} onChange={(updatedValue) => onChange(updatedValue, 'value', type)} />
      );
      break;
    case 'func':
      const funcConfig = FUNCTIONS[value?.func];
      const { widget: Widget } = funcConfig || { widget: null };
      component = (
        <>
          <FunctionSelector
            typeFilter={type}
            value={value?.func}
            onChange={(updatedFunc, returnType) => onChange(updatedFunc, 'func', returnType)}
          />
          {Widget && (
            <>
              (
              <Widget
                id={id}
                args={value?.args}
                onChange={(updatedFunc) => onChange(updatedFunc, 'func', funcConfig.returnType)}
              />
              )
            </>
          )}
        </>
      );
      break;
  }

  const showSourceSelector = [null, 'text', 'number', 'date', 'time', 'boolean', 'percentage'].includes(type);

  return (
    <div className="flex flex-wrap items-center gap-2">
      {showSourceSelector && (
        <ValueFieldSourceSelector
          enableValueSource={enableValueSource}
          source={source}
          onChange={(source) => onChange(null, source, type)}
        />
      )}
      {component}
    </div>
  );
};

export default ValueField;
