import type { FC } from 'react';
import React from 'react';
import type { Action, CaseGroup, RuleGroup } from '~/components/query-builder/types.ts';
import RuleGroupBuilder from '~/components/query-builder/RuleGroupBuilder.tsx';
import { IconButton } from '@ecainternational/eca-components';
import { useTranslation } from 'react-i18next';
import ActionSelector from '~/components/query-builder/ActionSelector.tsx';
import ActionBuilder from '~/components/query-builder/ActionBuilder.tsx';
import { createNewAction } from '~/components/query-builder/utils.ts';

interface ConditionBuilderProps {
  condition: CaseGroup;
  index: number;
  onChange: (condition: CaseGroup) => void;
  onDelete: () => void;
}
const ConditionBuilder: FC<ConditionBuilderProps> = ({ condition, index, onChange, onDelete }) => {
  const { t } = useTranslation();
  const { properties } = condition;
  const { actions } = properties;
  const handleOnChangeRule = (group: RuleGroup) => {
    const caseGroup: CaseGroup = {
      ...group,
      type: 'case_group',
      properties: { ...group.properties, actions },
    };
    onChange(caseGroup);
  };

  const handleChangeAction = (index: number, updatedAction: Action) => {
    const actionsToUpdate = [...actions];
    actionsToUpdate[index] = updatedAction;
    onChange({ ...condition, properties: { ...properties, actions: actionsToUpdate } });
  };

  const handleAddAction = (type: string, config: unknown) => {
    onChange({
      ...condition,
      properties: {
        ...properties,
        actions: [...actions, createNewAction(type, config)],
      },
    });
  };

  const handleDeleteAction = (index: number) => {
    const actionsToUpdate = actions.filter((_, i) => i !== index);
    onChange({ ...condition, properties: { ...properties, actions: actionsToUpdate } });
  };

  const group: RuleGroup = {
    id: condition.id,
    type: 'group',
    children1: condition.children1 || [],
    properties: condition.properties,
  };

  return (
    <div className="bg-neutral-layer-2 flex flex-col gap-3 rounded-lg p-4">
      <div className="flex items-center justify-between">
        <div className="heading-sm-mid text-neutral-body">
          {t('globalVariables.rule.caseHeading', { index: index + 1 })}
        </div>
        <IconButton
          name="deleteCase"
          title={t('globalVariables.rule.deleteCase')}
          aria-label={t('globalVariables.rule.deleteCase')}
          variant="standard"
          icon="fi-rr-trash"
          size="small"
          onClick={onDelete}
          className="focus-visible:text-states-error hover:text-states-error ml-auto"
        />
      </div>
      <div className="flex flex-col gap-2">
        <div className="label-sm-mid text-sm">IF</div>
        <RuleGroupBuilder group={group} onChange={handleOnChangeRule} isRoot />
      </div>
      <div className="flex flex-col gap-2">
        <div className="label-sm-mid text-sm">THEN</div>
        {actions.map((action, index) => (
          <ActionBuilder
            key={action.id}
            index={index}
            action={action}
            onChange={(update) => handleChangeAction(index, update)}
            onDelete={() => handleDeleteAction(index)}
          />
        ))}
        <ActionSelector onAdd={handleAddAction} />
      </div>
    </div>
  );
};

export default ConditionBuilder;
