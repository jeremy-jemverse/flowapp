import type { FC } from 'react';
import type { Field, Query, QueryMode } from '~/components/query-builder/types.ts';
import './QueryBuilder.css';
import ModeSelector from '~/components/query-builder/ModeSelector.tsx';
import SwitchGroupBuilder from '~/components/query-builder/SwitchGroupBuilder.tsx';
import { QueryBuilderContext } from './QueryBuilderContext';
import { createNewRuleGroup, createNewSwitchGroup } from '~/components/query-builder/utils.ts';
import RuleGroupBuilder from '~/components/query-builder/RuleGroupBuilder.tsx';

interface QueryBuilderProps {
  query: Query | null;
  fields: Field[];
  onChange: (query: Query) => void;
}
const QueryBuilder: FC<QueryBuilderProps> = ({ query, fields, onChange }) => {
  if (query === null) {
    onChange(createNewRuleGroup());
    return null;
  }

  const handleModeChange = (updatedMode: QueryMode) => {
    switch (updatedMode) {
      case 'switch_group':
        return onChange({ ...createNewSwitchGroup(), id: query.id });
      case 'group':
        return onChange({ ...createNewRuleGroup(), id: query.id });
    }
  };

  return (
    <QueryBuilderContext.Provider value={{ fields }}>
      <div className="flex flex-col gap-3">
        <div className="flex">
          <ModeSelector mode={query.type} onChange={handleModeChange} />
        </div>
        {query.type === 'group' && <RuleGroupBuilder group={query} onChange={onChange} isRoot />}
        {query.type === 'switch_group' && <SwitchGroupBuilder query={query} onChange={onChange} />}
      </div>
    </QueryBuilderContext.Provider>
  );
};

export default QueryBuilder;
