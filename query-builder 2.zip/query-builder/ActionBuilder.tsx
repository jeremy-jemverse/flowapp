import type { FC } from 'react';
import React from 'react';
import { ACTIONS } from '~/components/query-builder/config.ts';
import type { Action, ActionWidgetProps } from './types';
import { IconButton } from '@ecainternational/eca-components';
import { useTranslation } from 'react-i18next';

interface ActionBuilderProps {
  action: Action;
  index: number;
  onChange: (action: Action) => void;
  onDelete: () => void;
}
const ActionBuilder: FC<ActionBuilderProps> = ({ action, index, onChange, onDelete }) => {
  const { t } = useTranslation();
  const actionConfig = ACTIONS[action.type];
  const { widget: Widget } = actionConfig || { widget: UnrecognisedAction };
  return (
    <div className="bg-neutral-layer-3 w-full flex-col gap-3 rounded-lg p-4">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1">
          <span className="heading-sm-mid text-neutral-body">
            {t('globalVariables.rule.actionHeading', { index: index + 1 })}
          </span>
          <span className="text-visualisation-5-bold text-sm"> - {action.type}</span>
        </span>
        <IconButton
          name="deleteAction"
          title={t('globalVariables.rule.deleteAction')}
          aria-label={t('globalVariables.rule.deleteAction')}
          variant="standard"
          icon="fi-rr-trash"
          size="xsmall"
          onClick={onDelete}
          className="focus-visible:text-states-error hover:text-states-error ml-auto"
        />
      </div>
      <Widget action={action} onChange={onChange} />
    </div>
  );
};

const UnrecognisedAction: FC<ActionWidgetProps> = () => {
  const { t } = useTranslation();
  return <div className="text-states-error-bold label-sm-mid">{t('globalVariables.rule.actions.unrecognised')}</div>;
};
export default ActionBuilder;
