import { IconButton } from '@ecainternational/eca-components';
import type { FC } from 'react';
import React, { useMemo } from 'react';
import type {
  FieldType,
  Func,
  Operator,
  Rule,
  RuleProperties,
  ValueFieldSource,
} from '~/components/query-builder/types.ts';
import {
  getDefaultValueByOperator,
  getFieldType,
  getOperatorsByType,
  getValueType,
} from '~/components/query-builder/utils.ts';
import { useTranslation } from 'react-i18next';
import { useQueryBuilder } from '~/components/query-builder/QueryBuilderContext.tsx';
import OperatorSelector from './OperatorSelector.tsx';
import ValueField from '~/components/query-builder/ValueField.tsx';
import { FUNCTIONS } from '~/components/query-builder/config.ts';

interface LeftValueFieldProps {
  options?: { value: string; label: string }[];
  type: FieldType | null;
}
interface RuleBuilderProps {
  rule: Rule;
  onChange: (rule: Rule) => void;
  onDelete?: () => void;
}

const RuleBuilder: FC<RuleBuilderProps> = ({ rule, onChange, onDelete }) => {
  const { fields } = useQueryBuilder();
  const leftValueFieldProps = useMemo(() => {
    switch (rule.properties.fieldSrc) {
      case 'field':
        const field = fields.find((field) => field.id === rule.properties.field);
        const type = field ? getFieldType(field) : null;
        return { options: field?.options, type } as LeftValueFieldProps;
      case 'func':
        const func = FUNCTIONS[(rule.properties.field as Func)?.func];
        return { options: [], type: func?.returnType ?? null } as LeftValueFieldProps;
      default:
        return { options: [], type: null } as LeftValueFieldProps;
    }
  }, [fields, rule.properties.field, rule.properties.fieldSrc]);
  const { t } = useTranslation();
  const handleFieldChange = (field: any, fieldSrc: ValueFieldSource, fieldType: FieldType | null) => {
    const typeChanged = leftValueFieldProps.type !== fieldType;
    const operator = typeChanged ? getOperatorsByType(fieldType)[0] : rule.properties.operator;
    const value = typeChanged ? getDefaultValueByOperator(operator) : rule.properties.value;
    const valueSrc = typeChanged ? new Array(value.length).fill('value') : rule.properties.valueSrc;
    const valueType = typeChanged
      ? new Array(value.length).fill(getValueType(fieldType, operator))
      : rule.properties.valueType;
    const properties: RuleProperties = {
      field,
      fieldSrc,
      operator,
      value,
      valueSrc,
      valueType,
    };
    onChange({
      ...rule,
      properties,
    });
  };
  const handleOperatorSelect = (operator: Operator) => {
    const value = getDefaultValueByOperator(operator);
    const type = getValueType(leftValueFieldProps.type, operator);
    const properties: RuleProperties = {
      ...rule.properties,
      operator,
      value: getDefaultValueByOperator(operator),
      valueSrc: new Array(value.length).fill('value'),
      valueType: new Array(value.length).fill(type),
    };
    onChange({
      ...rule,
      properties,
    });
  };

  const handleValueChange = (value: any[], valueSrc: ValueFieldSource[], valueType: (FieldType | null)[]) => {
    const properties: RuleProperties = {
      ...rule.properties,
      value,
      valueSrc,
      valueType,
    };
    onChange({
      ...rule,
      properties,
    });
  };

  return (
    <div className="flex items-center gap-2">
      <span>=</span>
      <div className="flex flex-1 flex-wrap items-center gap-2">
        <ValueField
          id={`${rule.id}_field`}
          type={null}
          source={rule.properties.fieldSrc}
          value={rule.properties.field}
          onChange={(field, source, type) => handleFieldChange(field, source, type)}
        />

        {leftValueFieldProps.type && (
          <>
            <OperatorSelector
              operator={rule.properties.operator}
              type={leftValueFieldProps.type}
              onChange={handleOperatorSelect}
            />
            <RuleRHS options={leftValueFieldProps.options} rule={rule} onChange={handleValueChange} />
          </>
        )}
      </div>
      <IconButton
        name="deleteRule"
        title={t('globalVariables.rule.deleteRule')}
        aria-label={t('globalVariables.rule.deleteRule')}
        variant="standard"
        icon="fi-rr-trash"
        size="xsmall"
        onClick={onDelete}
        className="focus-visible:text-states-error hover:text-states-error ml-auto"
      />
    </div>
  );
};

export default RuleBuilder;

interface RuleRHSProps {
  rule: Rule;
  onChange: (value: any[], source: ValueFieldSource[], type: (FieldType | null)[]) => void;
  options?: { label: string; value: string }[];
}

const RuleRHS: FC<RuleRHSProps> = ({ rule, onChange, options }) => {
  const { t } = useTranslation();
  const { properties } = rule;
  const { operator, value, valueType, valueSrc } = properties;
  const handleOnChange = (
    index: number,
    updatedValue: any,
    updatedSource: ValueFieldSource,
    updatedType: FieldType | null,
  ) => {
    const values = [...value];
    const sources = [...valueSrc];
    const types = [...valueType];
    values[index] = updatedValue;
    sources[index] = updatedSource;
    types[index] = updatedType;
    onChange(values, sources, types);
  };

  if (operator === 'is_empty' || operator === 'is_not_empty') return null;
  if (operator === 'between' || operator === 'not_between') {
    return (
      <>
        <ValueField
          id={`${rule.id}_0`}
          enableValueSource
          type={valueType[0]}
          source={valueSrc[0]}
          value={value[0]}
          onChange={(value, source, type) => handleOnChange(0, value, source, type)}
          options={options}
        />
        <span className="label-sm-mid text-sm">{t('globalVariables.rule.and')}</span>
        <ValueField
          id={`${rule.id}_1`}
          enableValueSource
          type={valueType[1]}
          source={valueSrc[1]}
          value={value[1]}
          onChange={(value, source, type) => handleOnChange(1, value, source, type)}
          options={options}
        />
      </>
    );
  }

  return (
    <ValueField
      id={`${rule.id}`}
      enableValueSource
      type={valueType[0]}
      source={valueSrc[0]}
      value={value[0]}
      onChange={(value, source, type) => handleOnChange(0, value, source, type)}
      options={options}
    />
  );
};
